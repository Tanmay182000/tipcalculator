# TipCalculator
#Grapecity Assignment
-This is a tip calculator created by Rohan Patel using C# and .NET Framework
